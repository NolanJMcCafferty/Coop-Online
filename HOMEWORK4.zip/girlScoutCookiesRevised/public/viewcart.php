<?php
// Include the ShoppingCart class.  Since the session contains a
// ShoppingCard object, this must be done before session_start().
require "../application/cart.php";
session_start();
print_r($_SESSION);
echo "<br>after starting a session in viewcart...";
?>

<!DOCTYPE html>

<?php

// If this session is just beginning, store an empty ShoppingCart in it.
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = new ShoppingCart();
}


?>

<html lang="en">

<head>
<title>Girl Scout Cookie Shopping Cart</title>

<!-- Some styles for our table -->
<style>
  table, th, td {
    border: 1px solid black;
    border-collapse: collapse;
  }
  th {
    color: black;
  }
  td {
    color: gray;
  }
  th, td {
    padding: 15px;
  }
</style>

</head>

<body>

<h2>Girl Scout Cookie Shopping Cart</h2>

<p><?php


// create a var for the array
$_SESSION_ARRAY = $_SESSION['cart']->order;

// update the array
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  foreach($_SESSION['cart']->order as $key => $value){
    $result = $_POST[$key];
    // if updated quantity is 0
    if ($result == 0){
      unset($_SESSION['cart']->order[$key]);
    } else {
      // simply change the value from the given key
      $_SESSION['cart']->order[$key] = $result;
      $_SESSION_ARRAY = $_SESSION['cart']->order;
    }
  }
}

  // build the html table
  function build_table($_SESSION_ARRAY){

      // creates a form
      $html .= '<form method="post" action "">';
      // starts the table
      $html .= '<table>';
      // header row
      $html .= '<tr><th> Cookie </th> <th> Quantity </th> <th> Price </th> </tr>';

      // each row
      foreach($_SESSION['cart']->order as $key => $value){

        $price = $value * 5;
        $displayName = ShoppingCart::$cookieTypes[$key];
        $html .= '<tr>';
        $html .= '<td>' . $displayName . '<td><input type = "text" name = ' . $key . ' value =' . $value . ' /></td><td>' . $price .  '</td>';
        $html .= '</tr>';
      }
      // finish table
      $html .= '</table>';

      // submit button
      $html .= '<input type ="submit" name = "submit" value = "Submit" >';
      $html .= '</form>';
      return $html;
  }

  // display cost
  foreach ($_SESSION_ARRAY as $key => $value) {
    // get the actual name of cookie based off array key
    $TOTAL_COST += $value * 5;
  }



// call this method
echo build_table($_SESSION_ARRAY);
// total cost
echo '<hr><br\><span style="color:red;text-align:center;">TOTAL COST: $' . $TOTAL_COST . '</span>';


?></p>

<p><a href="index4.php">Resume shopping</a></p>

<p><a href="checkout.php">Check out</a></p>

</body>
</html>
