<?php

require "../application/cart.php";
session_start();
require 'dbConnect.php';
$connection = connect("gsc");
require 'queries.php';
?>

<! DOCTYPE html>

<?php
if($_POST['submit']) { // if form is submitted
	$name = $_POST['name'];
	$streetAddress = $_POST['street'];
	$state = $_POST['state'];
	$city = $_POST['city'];
	$zipcode = $_POST['zipcode'];
	$referal = $_POST['referal'];
	echo "$name, $streetAddress, $city, $state. $zipcode";

	mysqli_stmt_execute($selectCustomer);
	$selectCustomer -> bind_result($cid);
	if($selectCustomer -> fetch()) { //check if customer is already in database
		echo "Your ID is $cid <br>";
	} else { // insert customer id
		mysqli_stmt_execute($insertCustomer);
		print_r($connection->error);
		$cid = mysqli_stmt_insert_id($insertCustomer);
		echo "Welcome, Your new ID is $cid <br>";

	}
	// close the connections
	mysqli_stmt_close($selectCustomer);
	mysqli_stmt_close($insertCustomer);
	}

	?>
