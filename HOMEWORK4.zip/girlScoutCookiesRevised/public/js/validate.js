

var validateField = function(fieldElem, infoMessage, validateFn) {

    // call the main function
    validateFn(fieldElem);

    // get the span text element
    span = $(fieldElem).siblings()[0];

    // show the span when typing
    $(span).show();

    // switch span messages and class
    if(validateFn(fieldElem)){  // updated
        span.innerHTML = "Valid";  // updated ... update the span element

        // remove span class and give it new one
        $(span).removeClass();
        $(span).addClass("ok");
        return true;
    }
    else{
        span.innerHTML = infoMessage;

        $(span).removeClass();
        $(span).addClass("error");
        return false;
    }

};

// check to see if empty textbox, hide
function isEmpty(fieldElem) {
    if (fieldElem.value.length < 1){
        //$(span).hide();
        $(span).removeClass();
        $(span).addClass("info");
        span.innerHTML = "* ";
        return true;
    }
        return false;
}

var fNameBoolean = false;
// first name validation
function firstNameValidate(fieldElem) {
    var valCode = /^[a-z ,.'-]+$/i;

    if (fieldElem.value.match(valCode)){
        fieldElem.focus();
        fNameBoolean = true;
        return true;
    } else {
        fNameBoolean = false;
        fieldElem.focus();
        return false;
    }

}

var lNameBoolean = false;
// last name validation
function lastNameValidate(fieldElem) {
    var valCode = /^[a-zA-Z]+$/;

    if (fieldElem.value.match(valCode)){
        fieldElem.focus();
        lNameBoolean = true;
        return true;
    } else {
        lNameBoolean = false;
        fieldElem.focus();
        return false;
    }
}
//HELLO
// user name validation
function userNameValidate(fieldElem) {
    var valCode = /^[a-zA-Z]+$/;

    if (fieldElem.value.match(valCode) && fieldElem.value.length > 2){
        fieldElem.focus();
        return true;
    } else {
        fieldElem.focus();
        return false;
    }
}

function numberValidate(fieldElem) {
    var valCode = /^(\+\d{1,2}\s)?\(?\d{3}\)?[\s.-]\d{3}[\s.-]\d{4}$/;

    if (fieldElem.value.match(valCode)){
        fieldElem.focus();
        return true;
    } else {
        fieldElem.focus();
        return false;
    }
}

// email validation
function emailValidate(fieldElem) {

    var valCode = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;

    if (fieldElem.value.match(valCode)){
        fieldElem.focus();
        return true;
    } else {
        fieldElem.focus();
        return false;
    }

}


// troop validation
function troopValidate(fieldElem) {
    var valCode = /^[a-zA-Z]+$/;

    if (fieldElem.value.match(valCode)){
        fieldElem.focus();
        return true;
    } else {
        fieldElem.focus();
        return false;
    }
}


// zipcode validation
function zipcodeValidate(fieldElem) {
    var valCode = /^[0-9]+$/;

    if (fieldElem.value.match(valCode)){
        fieldElem.focus();
        return true;
    } else {
        fieldElem.focus();
        return false;
    }
}


// function submitFunction(){
//
//     var message = "";
//     console.log("submitted");
//
//     if(fNameBoolean == false){
//       console.log("empty");
//       message = "Make sure all required fields are filled in!";
//     }
//
//     alert(message);
// }



// call all the elements to validate
$(document).ready(function() {
    console.log("inside document ready!!");

    // call all the methods for each input box

    $('#fname').on("focus", function() {
        validateField(this, 'please enter a valid first name (a-z characters)', firstNameValidate);
    });


    $('#fname').on("keyup", function() {
        validateField(this, 'please enter a valid first name (a-z characters)', firstNameValidate);
    });

    $('#fname').on("blur", function() {
        isEmpty(this);
    });

    // $('#lname').on("keyup", function() {
    //     validateField(this, 'please enter a valid last name (a-z characters)', lastNameValidate);
    // });
    //
    // $('#lname').on("focus", function() {
    //     validateField(this, 'please enter a valid last name (a-z characters)', lastNameValidate);
    // });
    //
    // $('#lname').on("blur", function() {
    //     isEmpty(this);
    // });

    $('#username').on("keyup", function() {
        validateField(this, 'please enter a valid username (a-z characters and 3 or more characters)', userNameValidate);
    });

    $('#username').on("focus", function() {
        validateField(this, 'please enter a valid username (a-z characters and 3 or more characters)', userNameValidate);
    });

    $('#username').on("blur", function() {
        isEmpty(this);
    });

    $('#email').on("keyup", function() {
        validateField(this, 'Must be a valid email!', emailValidate);
    });

    $('#email').on("focus", function() {
        validateField(this, 'Must be a valid email!', emailValidate);
    });

    $('#email').on("blur", function() {
        isEmpty(this);
    });

    $('#number').on("keyup", function() {
        validateField(this, 'Must be a valid number (xxx-xxx-xxxx)!', numberValidate);
    });

    $('#number').on("focus", function() {
        validateField(this, 'Must be a valid number (xxx-xxx-xxxx)!', numberValidate);
    });

    $('#number').on("blur", function() {
        isEmpty(this);
    });

    $('#troop').on("keyup", function() {
        validateField(this, 'Must be a valid troop name!', troopValidate);
    });

    $('#troop').on("focus", function() {
        validateField(this, 'Must be a valid troop name!', troopValidate);
    });

    $('#troop').on("blur", function() {
        isEmpty(this);
    });

    $('#zipcode').on("keyup", function() {
        validateField(this, 'Must be a valid zipcode!', zipcodeValidate);
    });

    $('#zipcode').on("focus", function() {
        validateField(this, 'Must be a valid zipcode!', zipcodeValidate);
    });

    $('#zipcode').on("blur", function() {
        isEmpty(this);
    });

    // ajax call to autocomplete using JQUERY
    $('#state').autocomplete({
      source: [
        "Alabama",
        "Alaska",
        "Arizona",
        "Arkansas",
        "California",
        "Colorado",
        "Connecticut",
        "Delaware",
        "Florida",
        "Georgia",
        "Hawaii",
        "Idaho",
        "Illinois",
        "Indiana",
        "Iowa",
        "Kansas",
        "Kentucky",
        "Louisiana",
        "Maine",
        "Maryland",
        "Massachusetts",
        "Michigan",
        "Minnesota",
        "Mississippi",
        "Missouri",
        "Montana",
        "Nebraska",
        "Nevada",
        "New Hampshire",
        "New Jersey",
        "New Mexico",
        "New York",
        "North Carolina",
        "North Dakota",
        "Ohio",
        "Oklahoma",
        "Oregon",
        "Pennsylvania",
        "Rhode Island",
        "South Carolina",
        "South Dakota",
        "Tennessee",
        "Texas",
        "Utah",
        "Vermont",
        "Virginia",
        "Washington",
        "West Virginia",
        "Wisconsin",
        "Wyoming",
        "District of Columbia",
        "Puerto Rico",
        "Guam",
        "American Samoa",
        "U.S. Virgin Islands",
        "Northern Mariana Islands"
      ],
    });


});


// complete     \
